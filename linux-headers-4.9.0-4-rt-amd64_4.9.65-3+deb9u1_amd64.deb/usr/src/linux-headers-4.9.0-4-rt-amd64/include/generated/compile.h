/* This file is auto generated, version 1 */
/* SMP PREEMPT RT */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP PREEMPT RT Debian 4.9.65-3+deb9u1 (2017-12-23)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc version 6.3.0 20170516 (Debian 6.3.0-18) "
